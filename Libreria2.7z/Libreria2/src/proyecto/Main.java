package proyecto;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ventas v1 = new Ventas("JK58PQRSGDFGDG","14 de Junio de 2020,","El Quijote","la casa del libro");
		
		
		
		
		Libros l1 = new Libros("QWERTYUIOP","25.50€","Miguel de Cervantes","Novela");
		
		
		
		
		Autor a1 = new Autor("452POGB69","Miguel de Cervantes");
		
		
		
		
		v1.ImprimirDatosVentas();
		
		l1.ImprimirDatosLibro();
		
		a1.ImprimirDatosAutor();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
