package p2;

import java.util.Scanner;

public class P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//DECLARACION DE VARIABLES
		
		int numero;
		Scanner input = new Scanner(System.in);
		double sum=0;
		
		System.out.println("digite un numero: ");
		
		for(int i=0;i<15;i++) {
			numero = input.nextInt();
			System.out.println(i+2+" digite un numero: ");
			sum=sum+numero;
			System.out.println(sum);
		}
		System.out.println("la suma de los 15 numeros anteriores es: "+sum);
		
		
		
		
	}

}
