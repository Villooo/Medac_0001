/**
 * 
 */
/**
 * @author Usuario
 *
 */
module Tema4.Practicas1_10 {
	requires java.desktop;
}