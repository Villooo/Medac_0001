package p4;

import java.util.Scanner;

public class P4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		int n1,NoDivisibles = 0;
		int iFactorial = 1;
		
		System.out.println("Introduce numeros divisibles entre 2 y te dire su factorial");
		
		
		for(int i=0;NoDivisibles!=3;i++) {
			System.out.println("Digite su numero: ");	
			n1 = input.nextInt();
			if(n1%2 !=0) {
				NoDivisibles++;
			System.out.println("El numero introducido no es divisible entre 2, por favor introduzca otro numero");
			}
			else {
				for (int x=2;x<=n1;x++)
					  iFactorial = iFactorial * x;
				System.out.println("El factorial del número " + Integer.toString(n1) +  " es " + Integer.toString(iFactorial));

			}
		}
		
		System.out.println("ha introducido 3 numeros impares, por favor introduca numeros divisibles entre 2");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
