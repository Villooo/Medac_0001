package p5;

import java.util.Scanner;

public class P5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//DECLARIACIÓN DE VARIABLES
		Scanner input = new Scanner(System.in);
		double Importe;
		double sum=0;
		double Mas1000=0;
		
		System.out.println("Usted es dueño de una fabrica de magdalenas y se han borrado los costes de las ultimas 10 facturas, introduce los 10 importes para que se guarden en la base de datos");
		
		for(int NumeroImportes=1;NumeroImportes<=10;NumeroImportes++) {
			System.out.println("digite la factura nº "+NumeroImportes+": ");
			Importe = input.nextDouble();
			sum=Importe+sum;
			
			if (Importe>=1000) {
				Mas1000++;
			}
			
			if(Importe<=0) {
				System.out.println("Digite solo numeros positivos");
					break;
			}
		}
			
			System.out.println("La suma de las 10 facturas es de "+sum+" y ha habido "+Mas1000+" facturas que superan los 1000€");
		
		
		
		
		
		
		
		
		
	}

}
