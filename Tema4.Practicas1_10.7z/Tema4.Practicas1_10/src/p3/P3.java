package p3;

public class P3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		for(int numeros = 1;numeros<20;numeros+=2) {
			System.out.println(numeros);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
