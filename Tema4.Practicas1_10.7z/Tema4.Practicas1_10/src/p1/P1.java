package p1;

import java.util.Iterator;
import java.util.Scanner;

public class P1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//DECLARAICION DE VARIABLES		
		Scanner input = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);
		
		int TotalNumeros=0;
		System.out.println("Hola, ingresa el total de numeros que quiere introducir ");
		TotalNumeros = input.nextInt();
		double Contador=0;
		int[] numeros= new int[TotalNumeros];
		double sum=0;

		
//SINTAXIS DEL PROGRAMA
		
		for(int i=0;i<numeros.length;i++) {
			System.out.println("introduce el numero: ");	
			numeros[i] = input.nextInt();
			if(numeros[i]>0) {
		
			sum+=numeros[i];
			Contador++;
			
			}
			
			if(numeros[i]<0) {
				System.out.println("Ha introducido un numero negativo, el programa no admite numreos negativos");
				break;
			}
			
			
		}
		
		System.out.println("ha introducido "+Contador+" numeros y la media de estos es: "+sum/Contador);
		
		
		
		
		
		
	}

}
