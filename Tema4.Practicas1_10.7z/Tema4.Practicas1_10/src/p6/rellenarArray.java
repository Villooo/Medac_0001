package p6;
import java.security.SecureRandom;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class rellenarArray {

	public static void main(String[] args) {
		ArrayList<Integer> numeros1 = new ArrayList<>();
		ArrayList<Integer> numeros2 = new ArrayList<>();
		rellenarArray(numeros2);
		rellenarArray(numeros1);

	}

	public static void rellenarArray(ArrayList<Integer> n) {
		int longitud;
		int numero;
		SecureRandom random = new SecureRandom();
		longitud = Integer.parseInt(JOptionPane.showInputDialog("Digite la longitud del array deseado"));
		for (int i = 0; i < longitud; i++) {
			numero = random.nextInt((10)+1);
			n.add(numero);
		}
		JOptionPane.showMessageDialog(null, n);
	}

}

